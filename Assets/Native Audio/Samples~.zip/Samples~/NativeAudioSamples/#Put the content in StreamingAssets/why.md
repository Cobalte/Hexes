﻿The new Samples importing workflow will import everything neatly to a contained folder, great, but that make the samples incomplete if it cannot mess with magic folders like `Resources` or `StreamingAssets`.

So I have to ask you to help me do that :)