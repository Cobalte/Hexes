﻿//#define TESTLAB

using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using E7.Native;
using UnityEngine;
using UnityEngine.UI;
using Debug = UnityEngine.Debug;

namespace E7.NativeAudioSamples
{
    public class NativeAudioDemoPerformance : MonoBehaviour
    {
        private const float secondsOfPlay = 1.5f;
        private const int framesOfPlay = (int) (60 * secondsOfPlay);
        [SerializeField] private Text fpsText;
        [SerializeField] private Text resultText;

        [Space]
        [SerializeField] private AudioSource audioSource;

        [SerializeField] private Image background;
        [SerializeField] private Color color1;
        [SerializeField] private Color color2;

        private NativeAudioPointer loaded;
        private PerformanceResult pr;

        private bool running;

        private Stopwatch sw;

        public IEnumerator Start()
        {
            StartCoroutine(FPSUpdate());
#if !TESTLAB
            yield break;
#else
        StartPerformanceTest();
        yield return new WaitUntil(() => running == false);
        background.color = color1;
        StartPerformanceTest();
        yield return new WaitUntil(() => running == false);
        background.color = color2;
#endif
        }

        public void Update()
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                audioSource.Play();
            }
        }

        private IEnumerator FPSUpdate()
        {
            while (true)
            {
                fpsText.text = (1 / Time.deltaTime).ToString("0.00");
                yield return new WaitForSeconds(0.1f);
            }
        }

        public void StartPerformanceTest()
        {
            Application.targetFrameRate = 60;
            if (!running)
            {
                StartCoroutine(PerformanceTest());
            }
        }

        public IEnumerator PerformanceTest()
        {
            running = true;
            sw = new Stopwatch();
            pr = new PerformanceResult();
            audioSource.clip.UnloadAudioData();
            Debug.Log("Performance test : AudioSource..");
            Debug.Log("Performance test : AudioSource loading..");

            sw.Start();
            audioSource.clip.LoadAudioData();
            sw.Stop();
            pr.asLoad = sw.ElapsedTicks;
            sw.Reset();

            yield return new WaitForSeconds(0.5f);

            Debug.Log("Performance test : AudioSource playing..");

            for (var i = 0; i < framesOfPlay; i++)
            {
                Debug.Log("Performance test : AudioSource frame " + i);
                sw.Start();
                audioSource.Play();
                yield return null;
                sw.Stop();
                pr.asTicks.Add(sw.ElapsedTicks);
                sw.Reset();
            }

            yield return new WaitForSeconds(0.5f);

            if (!Application.isEditor)
            {
                Debug.Log("Performance test : NativeAudio initializing..");

                sw.Start();
                //This force the "crash prevention mechanism" to activates. If it crashes then... it is a bug.
                NativeAudio.Initialize(new NativeAudio.InitializationOptions {androidAudioTrackCount = 3});
                sw.Stop();
                pr.naInitialize = sw.ElapsedTicks;
                sw.Reset();

                yield return new WaitForSeconds(0.5f);

                Debug.Log("Performance test : NativeAudio silently analyzing..");

                var analyzer = NativeAudio.SilentAnalyze();
                yield return new WaitUntil(() => analyzer.Analyzed);
                pr.silenceAnalysis = analyzer.AnalysisResult.averageFps;

                Debug.Log("Performance test : NativeAudio loading..");

                sw.Start();
                loaded = NativeAudio.Load("NativeAudioDemo1.wav");
                yield return null;
                sw.Stop();
                pr.naLoad = sw.ElapsedTicks;
                sw.Reset();

                yield return new WaitForSeconds(0.5f);

                Debug.Log("Performance test : NativeAudio playing..");

                for (var i = 0; i < framesOfPlay; i++)
                {
                    Debug.Log("Performance test : NativeAudio frame " + i);
                    sw.Start();
                    NativeAudio.GetNativeSourceAuto().Play(loaded);
                    yield return null;
                    sw.Stop();
                    pr.naTicks.Add(sw.ElapsedTicks);
                    sw.Reset();
                }

                yield return new WaitForSeconds(0.5f);
            }

            Debug.Log("Performance test : Ending..");

            resultText.text = pr.AnalysisText;

            running = false;
        }

        private class PerformanceResult
        {
            public long asLoad;
            public readonly List<long> asTicks = new List<long>();

            public long naInitialize;
            public long naLoad;
            public readonly List<long> naTicks = new List<long>();

            public float silenceAnalysis;

            public string AnalysisText
            {
                get
                {
                    if (naTicks.Count == 0)
                    {
                        naTicks.Add(0);
                    }

                    string[] a =
                    {
                        "AudioSource Load : [Ticks] " + asLoad + " [Ms] " + TicksToMs(asLoad),
                        "AudioSource Play : [Avg. Ticks] " + asTicks.Average() + " [Avg. Ms] " +
                        TicksToMs(asTicks.Average()) + " [Avg. FPS] " + 1000 / TicksToMs(asTicks.Average()),
                        "AudioSource Play : [SD Ticks] " + StdDev(asTicks) + " [SD Ms] " + TicksToMs(StdDev(asTicks)),
                        "",
                        "Silent analysis : [Avg. FPS] " + silenceAnalysis,
                        "",
                        "NativeAudio Initialize : [Ticks] " + naInitialize + " [Ms] " + TicksToMs(naInitialize),
                        "NativeAudio Load : [Ticks] " + naLoad + " [Ms] " + TicksToMs(naLoad),
                        "NativeAudio Play : [Avg. Ticks] " + naTicks.Average() + " [Avg. Ms] " +
                        TicksToMs(naTicks.Average()) + " [Avg. FPS] " + 1000 / TicksToMs(naTicks.Average()),
                        "NativeAudio Play : [SD Ticks] " + StdDev(naTicks) + " [SD Ms] " + TicksToMs(StdDev(naTicks)),
                    };
                    return string.Join("\n", a);
                }
            }

            private float TicksToMs(long ticks)
            {
                return ticks / 10000f;
            }

            private float TicksToMs(double ticks)
            {
                return (float) (ticks / 10000);
            }

            private static float StdDev(IEnumerable<long> values)
            {
                float ret = 0;
                var count = values.Count();
                if (count > 1)
                {
                    var avg = (float) values.Average();
                    var sum = values.Sum(d => (d - avg) * (d - avg));
                    ret = Mathf.Sqrt(sum / count);
                }

                return ret;
            }
        }
    }
}